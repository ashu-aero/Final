package com.nms;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "status")
public class Status {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; 
	
	@Column(name = "ip_address", nullable = false, length = 50)
	private String ip_address; 
	
	@Column(name="dtimestamp")
	private Timestamp dtimestamp;
	
	@Column(name="utimestamp")
	private Timestamp utimestamp;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the ip_address
	 */
	public String getIp_address() {
		return ip_address;
	}

	/**
	 * @param ip_address the ip_address to set
	 */
	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}

	/**
	 * @return the dtimestamp
	 */
	public Timestamp getDtimestamp() {
		return dtimestamp;
	}

	/**
	 * @param dtimestamp the dtimestamp to set
	 */
	public void setDtimestamp(Timestamp dtimestamp) {
		this.dtimestamp = dtimestamp;
	}

	/**
	 * @return the utimestamp
	 */
	public Timestamp getUtimestamp() {
		return utimestamp;
	}

	/**
	 * @param utimestamp the utimestamp to set
	 */
	public void setUtimestamp(Timestamp utimestamp) {
		this.utimestamp = utimestamp;
	} 
	
	 
}
