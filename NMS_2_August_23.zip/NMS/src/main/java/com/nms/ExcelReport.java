package com.nms;
import java.util.ArrayList;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ExcelReport {

	@Autowired
	private StatusRepository statusRepo;

	public void generateExcel(HttpServletResponse response, ArrayList<Report> arrayListReport) throws Exception {

		//List<Status> statusList = statusRepo.findAll();
		 

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Network Status");
		HSSFRow row = sheet.createRow(0);

		 
		row.createCell(0).setCellValue("Location");
		row.createCell(1).setCellValue("Provider");
		row.createCell(2).setCellValue("IP address");
		row.createCell(3).setCellValue("Down Time");
		row.createCell(4).setCellValue("Up Time");
		row.createCell(5).setCellValue("Total Down Time(HH:MM:SS)");

		int dataRowIndex = 1;

		for (Report report : arrayListReport) {
			HSSFRow dataRow = sheet.createRow(dataRowIndex);
			dataRow.createCell(0).setCellValue(report.getLocation());
			dataRow.createCell(1).setCellValue(report.getServiceProvider());
			dataRow.createCell(2).setCellValue(report.getIp());
			dataRow.createCell(3).setCellValue(report.getDownTime());
			dataRow.createCell(4).setCellValue(report.getUpTime());
			dataRow.createCell(5).setCellValue(report.getTotalDownTime());
			dataRowIndex++;
		}

		ServletOutputStream ops = response.getOutputStream();
		workbook.write(ops);
		workbook.close();
		ops.close();

	}

}